const form = document.getElementById("rentForm");
const tableBody = document.querySelector("#tenantTable tbody");
const message = document.getElementById("message");
const searchInput = document.getElementById("searchInput");

// Load tenants from Local Storage
let tenants = JSON.parse(localStorage.getItem("tenants")) || [];

// Display all tenants
function displayTenants() {
    tableBody.innerHTML = "";

    let paid = 0;
    let unpaid = 0;

    tenants.forEach((tenant, index) => {

        const row = tableBody.insertRow();

        row.insertCell(0).textContent = tenant.name;
        row.insertCell(1).textContent = tenant.phone;
        row.insertCell(2).textContent = tenant.house;
        row.insertCell(3).textContent = tenant.rent;

        const statusCell = row.insertCell(4);
        statusCell.textContent = tenant.status;
        statusCell.style.color =
            tenant.status === "Paid" ? "green" : "red";

        const actionCell = row.insertCell(5);

        // Paid Button
        const paidBtn = document.createElement("button");
        paidBtn.textContent = "Paid";

        paidBtn.onclick = function () {
            tenants[index].status = "Paid";
            localStorage.setItem("tenants", JSON.stringify(tenants));
            displayTenants();
        };

        // Delete Button
        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.style.background = "red";

        deleteBtn.onclick = function () {
            tenants.splice(index, 1);
            localStorage.setItem("tenants", JSON.stringify(tenants));
            displayTenants();
        };

        actionCell.appendChild(paidBtn);
        actionCell.appendChild(document.createElement("br"));
        actionCell.appendChild(deleteBtn);

        if (tenant.status === "Paid") {
            paid++;
        } else {
            unpaid++;
        }

    });

    document.getElementById("totalTenants").textContent = tenants.length;
    document.getElementById("paidTenants").textContent = paid;
    document.getElementById("unpaidTenants").textContent = unpaid;
}

// Save Tenant
form.addEventListener("submit", function (event) {
    event.preventDefault();

    const tenant = {
        name: document.getElementById("name").value,
        phone: document.getElementById("phone").value,
        house: document.getElementById("house").value,
        rent: document.getElementById("rent").value,
        status: "Unpaid"
    };

    tenants.push(tenant);

    localStorage.setItem("tenants", JSON.stringify(tenants));

    message.textContent = "✅ Tenant registered successfully!";

    form.reset();

    displayTenants();
});

// Search Tenant
searchInput.addEventListener("keyup", function () {

    const filter = searchInput.value.toLowerCase();

    const rows = tableBody.getElementsByTagName("tr");

    for (let i = 0; i < rows.length; i++) {

        const name = rows[i].cells[0].textContent.toLowerCase();
        const house = rows[i].cells[2].textContent.toLowerCase();

        if (name.includes(filter) || house.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }

});

// Display saved tenants when page loads
displayTenants();
function logout(){
    window.location.href = "login.html";
}
function registerTenant(){

    let name = document.getElementById("name").value;
    let phone = document.getElementById("phone").value;
    let house = document.getElementById("house").value;
    let rent = document.getElementById("rent").value;

    let tenant = {
        name: name,
        phone: phone,
        house: house,
        rent: rent
    };

    let tenants = JSON.parse(localStorage.getItem("tenants")) || [];

    tenants.push(tenant);

    localStorage.setItem("tenants", JSON.stringify(tenants));

    document.getElementById("message").innerHTML =
    "Tenant registered successfully!";
}
function makePayment(){

    let tenantName = document.getElementById("tenantName").value;
    let houseNumber = document.getElementById("houseNumber").value;
    let amount = document.getElementById("amount").value;
    let date = document.getElementById("date").value;

    let payment = {
        tenantName: tenantName,
        houseNumber: houseNumber,
        amount: amount,
        date: date
    };

    let payments = JSON.parse(localStorage.getItem("payments")) || [];

    payments.push(payment);

    localStorage.setItem("payments", JSON.stringify(payments));

    document.getElementById("paymentMessage").innerHTML =
    "Payment recorded successfully!";
    window.location.href = "receipt.html";
}
function addHouse(){

    let number = document.getElementById("houseNumber").value;
    let type = document.getElementById("houseType").value;
    let rent = document.getElementById("houseRent").value;

    let house = {
        number: number,
        type: type,
        rent: rent
    };

    let houses = JSON.parse(localStorage.getItem("houses")) || [];

    houses.push(house);

    localStorage.setItem("houses", JSON.stringify(houses));

    document.getElementById("houseMessage").innerHTML =
    "House added successfully.";

    location.reload();

}
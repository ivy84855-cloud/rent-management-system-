const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username === "admin" && password === "1234") {

        window.location.href = "rent.html";

    } else {

        document.getElementById("loginMessage").textContent =
            "❌ Invalid username or password!";
        document.getElementById("loginMessage").style.color = "red";
    }
});